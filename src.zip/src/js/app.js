import { bodyAnimationPlay } from "./sections/body/index.js";
import { BODY_PHASE_STATIC } from "./sections/body/constants.js";
import { BODY_PHASE_SIGNED_IN_CONTENT } from "./sections/body/constants.js";
import { BODY_PHASE_SIGNED_OUT_CONTENT } from "./sections/body/constants.js";
import { BODY_PHASE_START } from "./sections/body/constants.js";
import { headerAnimationPlay } from "./sections/header/index.js";
import { HEADER_PHASE_CONTENT } from "./sections/header/constants.js";
import { HEADER_PHASE_STATIC } from "./sections/header/constants.js";
import { HEADER_PHASE_FADE_IN } from "./sections/header/constants.js";
import { HEADER_PHASE_START } from "./sections/header/constants.js";
import { initSectionModules } from "./sections/section-index.js";
import { loadSections } from "./sections/section-index.js";
import { registerSections } from "./sections/section-index.js";
import { searchRunReveal } from "./sections/search/index.js";
import { searchApply } from "./sections/search/index.js";
import { themeInit } from "./utils/utility-theme.js";
import { checkAuth, refreshAuth } from "./utils/utility-auth.js";
import { authNumberGet } from "./accounts/accounts-index.js";
import { dataSync } from "./accounts/accounts-index.js";
import { hasPendingPostLoginReveal } from "./sections/codes/codes-reveal.js";
import { setEmptyVisible } from "./sections/codes/codes-empty.js";
import { SELECTORS } from "./sections/codes/codes-state.js";
import { loadTimerInvertedPreference } from "./sections/codes/codes-timer.js";
import { BODY_PHASE_EXTENSION_FRAME } from "./sections/body/constants.js";
import { BODY_PHASE_HEADER } from "./sections/body/constants.js";
import { BODY_PHASE_LOGO } from "./sections/body/constants.js";

themeInit();

/** Runs logo, extension-frame, header, and header fade-in phases. */
async function runBootstrapAnimation() {
  await bodyAnimationPlay(BODY_PHASE_LOGO);
  await bodyAnimationPlay(BODY_PHASE_EXTENSION_FRAME);
  await bodyAnimationPlay(BODY_PHASE_HEADER);
  await headerAnimationPlay(HEADER_PHASE_FADE_IN);
}

/** Registers sections, applies auth, plays animations, and loads section modules. */
async function bootstrapExtension() {
  registerSections();
  initSectionModules();

  const isLoggedIn = await checkAuth();
  await refreshAuth();
  searchApply(isLoggedIn);

  headerAnimationPlay(HEADER_PHASE_START);
  bodyAnimationPlay(BODY_PHASE_START);

  let signedInEmpty = false;

  if (isLoggedIn && !hasPendingPostLoginReveal()) {
    const authNumber = await authNumberGet();

    if (authNumber) {
      try {
        await loadTimerInvertedPreference();
        const accounts = await dataSync(authNumber);
        signedInEmpty =
          accounts.filter((account) => account?.secret).length === 0;
      } catch {
        return;
      }
    }
  }

  await runBootstrapAnimation();
  await headerAnimationPlay(HEADER_PHASE_CONTENT);

  if (!isLoggedIn) {
    await bodyAnimationPlay(BODY_PHASE_SIGNED_OUT_CONTENT);
  } else if (signedInEmpty) {
    const empty = document.querySelector(SELECTORS.empty);
    const list = document.querySelector(SELECTORS.list);

    setEmptyVisible(empty, list, true);
    await bodyAnimationPlay(BODY_PHASE_SIGNED_IN_CONTENT);
  }

  if (isLoggedIn && !hasPendingPostLoginReveal()) {
    await searchRunReveal();
  }

  headerAnimationPlay(HEADER_PHASE_STATIC);
  bodyAnimationPlay(BODY_PHASE_STATIC);
  await loadSections();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    void bootstrapExtension();
  });
} else {
  void bootstrapExtension();
}
