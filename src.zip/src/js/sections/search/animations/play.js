import { searchAnimateForFadeIn } from "./fade-in.js";
import { searchAnimateForStatic } from "./static.js";
import { searchAnimateForStart } from "./start.js";
import { SEARCH_PHASE_FADE_IN } from "../constants.js";
import { SEARCH_PHASE_STATIC } from "../constants.js";
import { SEARCH_PHASE_START } from "../constants.js";

/** Dispatches a search animation phase by key. */
export async function searchAnimationPlay(phase, options = {}) {
  if (phase === SEARCH_PHASE_START) {
    searchAnimateForStart();
    return;
  }

  if (phase === SEARCH_PHASE_FADE_IN) {
    await searchAnimateForFadeIn();
    return;
  }

  if (phase === SEARCH_PHASE_STATIC) {
    searchAnimateForStatic(options);
  }
}
