import { BODY_CONTENT_SIGNED_IN_SELECTOR } from "../../body/constants.js";
import { BODY_CONTENT_SIGNED_OUT_SELECTOR } from "../../body/constants.js";
import { BODY_HIDDEN_CLASS } from "../../body/constants.js";
import { BODY_MESSAGE_SPACER_SELECTOR } from "../../body/constants.js";
import { BODY_MESSAGE_STACK_SELECTOR } from "../../body/constants.js";
import { BODY_ROOT_SELECTOR } from "../../body/constants.js";
import { BODY_SIGNED_IN_VIEW_SELECTOR } from "../../body/constants.js";
import { BODY_SIGNED_OUT_VIEW_SELECTOR } from "../../body/constants.js";
import { EXTENSION_FRAME_SELECTOR } from "../../body/constants.js";
import { SEARCH_HIDDEN_CLASS } from "../constants.js";
import { SEARCH_PENDING_CLASS } from "../constants.js";
import { SEARCH_REFERENCE_MESSAGE_LINES } from "../constants.js";
import { SEARCH_ROOT_SELECTOR } from "../constants.js";
import { SEARCH_SLOT_OPEN_CLASS } from "../constants.js";
import { SEARCH_VAR_FRAME_BODY_TOP } from "../constants.js";
import { searchStateGet } from "../state.js";

/** Opens the search slot and sets the body top target before the search-bar phase. */
export function searchAnimateForStart() {
  const search = document.querySelector(SEARCH_ROOT_SELECTOR);
  const { isAuthVisible, isRevealed } = searchStateGet();

  if (!search || !isAuthVisible || isRevealed) {
    return;
  }

  const frame = document.querySelector(EXTENSION_FRAME_SELECTOR);
  const signedOutView = document.querySelector(BODY_SIGNED_OUT_VIEW_SELECTOR);
  const signedInView = document.querySelector(BODY_SIGNED_IN_VIEW_SELECTOR);
  const isSignedOut =
    signedOutView && !signedOutView.classList.contains(BODY_HIDDEN_CLASS);
  const contentSelector = isSignedOut
    ? BODY_CONTENT_SIGNED_OUT_SELECTOR
    : BODY_CONTENT_SIGNED_IN_SELECTOR;
  const content = document.querySelector(contentSelector);
  let contentOffsetPx = 0;

  if (content && !content.classList.contains("hidden")) {
    const stack = content.querySelector(BODY_MESSAGE_STACK_SELECTOR);
    const spacer = stack?.querySelector(BODY_MESSAGE_SPACER_SELECTOR);

    if (spacer) {
      const body = document.querySelector(BODY_ROOT_SELECTOR);
      const bodyStyles = body ? getComputedStyle(body) : null;
      const messageSize =
        Number.parseFloat(bodyStyles?.getPropertyValue("--body-message-size")) || 14;
      const referenceHeight = messageSize * 1.5 * SEARCH_REFERENCE_MESSAGE_LINES;
      const measuredHeight = spacer.getBoundingClientRect().height;

      contentOffsetPx = Math.max(0, Math.round(referenceHeight - measuredHeight));
    }
  }

  frame?.style.setProperty(
    SEARCH_VAR_FRAME_BODY_TOP,
    `calc(var(--frame-animate-for-header-body-top) + var(--search-slot-gap) + var(--codes-search-block-height) + ${contentOffsetPx}px)`,
  );

  search.classList.remove(SEARCH_HIDDEN_CLASS);
  search.classList.add(SEARCH_SLOT_OPEN_CLASS, SEARCH_PENDING_CLASS);
}
