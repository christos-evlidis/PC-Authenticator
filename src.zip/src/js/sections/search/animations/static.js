import { searchStateSet } from "../state.js";
import { SEARCH_FADING_IN_CLASS } from "../constants.js";
import { SEARCH_HIDDEN_CLASS } from "../constants.js";
import { SEARCH_PENDING_CLASS } from "../constants.js";
import { SEARCH_ROOT_SELECTOR } from "../constants.js";
import { SEARCH_SLOT_OPEN_CLASS } from "../constants.js";
import { SEARCH_VISIBLE_CLASS } from "../constants.js";

/** Reveals the search bar immediately without animation. */
export function searchAnimateForStatic() {
  const search = document.querySelector(SEARCH_ROOT_SELECTOR);

  if (!search || search.classList.contains(SEARCH_HIDDEN_CLASS)) {
    return;
  }

  search.classList.remove(SEARCH_PENDING_CLASS, SEARCH_FADING_IN_CLASS);
  search.classList.add(SEARCH_SLOT_OPEN_CLASS, SEARCH_VISIBLE_CLASS);
  searchStateSet({ isRevealed: true });
}
