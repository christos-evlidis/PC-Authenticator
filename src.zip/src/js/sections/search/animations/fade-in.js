import { cssMs } from "../../../utils/utility-animation.js";
import { waitForAnimationEnd } from "../../../utils/utility-animation.js";
import { waitForNextFrame } from "../../../utils/utility-animation.js";
import { SEARCH_ANIMATION_TIMEOUT_BUFFER_MS } from "../constants.js";
import { SEARCH_FADING_IN_CLASS } from "../constants.js";
import { SEARCH_PENDING_CLASS } from "../constants.js";
import { SEARCH_ROOT_SELECTOR } from "../constants.js";
import { SEARCH_VAR_FADE_IN_MS } from "../constants.js";
import { SEARCH_VISIBLE_CLASS } from "../constants.js";
import { searchStateSet } from "../state.js";

/** Fades the search bar in after the body slot has opened. */
export async function searchAnimateForFadeIn() {
  const search = document.querySelector(SEARCH_ROOT_SELECTOR);
  const fadeInMs = cssMs(search, SEARCH_VAR_FADE_IN_MS);

  if (!search) {
    return;
  }

  await waitForNextFrame();
  search.classList.add(SEARCH_FADING_IN_CLASS);

  await waitForAnimationEnd(
    search,
    "searchFadeIn",
    fadeInMs + SEARCH_ANIMATION_TIMEOUT_BUFFER_MS,
  );

  search.classList.remove(SEARCH_PENDING_CLASS, SEARCH_FADING_IN_CLASS);
  search.classList.add(SEARCH_VISIBLE_CLASS);
  searchStateSet({ isRevealed: true });
}
