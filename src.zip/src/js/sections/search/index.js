export { searchAnimationPlay } from "./animations/play.js";
export { searchFilterApply } from "./actions/filter.js";
export { searchReset } from "./actions/reset.js";

import { bodyAnimationPlay } from "../body/index.js";
import { BODY_PHASE_SEARCH_BAR } from "../body/constants.js";
import { searchFilterApply } from "./actions/filter.js";
import { searchReset } from "./actions/reset.js";
import { searchAnimationPlay } from "./animations/play.js";
import { SEARCH_HIDDEN_CLASS } from "./constants.js";
import { SEARCH_INPUT_SELECTOR } from "./constants.js";
import { SEARCH_PHASE_FADE_IN } from "./constants.js";
import { SEARCH_PHASE_START } from "./constants.js";
import { SEARCH_ROOT_SELECTOR } from "./constants.js";
import { searchStateGet } from "./state.js";
import { searchStateSet } from "./state.js";

/** Wires search input filtering. */
export function searchInit() {
  document.querySelector(SEARCH_INPUT_SELECTOR)?.addEventListener("input", () => {
    searchFilterApply();
  });
}

/** Applies search auth visibility without revealing during login. */
export function searchApply(isAuthVisible) {
  const search = document.querySelector(SEARCH_ROOT_SELECTOR);

  searchStateSet({ isAuthVisible });

  if (!search) {
    return;
  }

  if (!isAuthVisible) {
    search.classList.add(SEARCH_HIDDEN_CLASS);
    searchReset();
    return;
  }

  if (!searchStateGet().isRevealed) {
    search.classList.add(SEARCH_HIDDEN_CLASS);
    return;
  }

  search.classList.remove(SEARCH_HIDDEN_CLASS);
}

/** Opens the body slot, then fades the search bar in. */
export async function searchRunReveal() {
  searchAnimationPlay(SEARCH_PHASE_START);
  await bodyAnimationPlay(BODY_PHASE_SEARCH_BAR);
  await searchAnimationPlay(SEARCH_PHASE_FADE_IN);
}
