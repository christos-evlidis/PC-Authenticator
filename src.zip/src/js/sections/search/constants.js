// Selectors
export const SEARCH_ROOT_SELECTOR = ".codes-search";
export const SEARCH_INPUT_SELECTOR = ".codes-search__input";

export const SEARCH_FILTER_CARD_SELECTOR =
  ".account-block:not(.account-block--manual-add-spacer):not(.account-block--exit-spacer)";

// State classes
export const SEARCH_HIDDEN_CLASS = "hidden";
export const SEARCH_SLOT_OPEN_CLASS = "is-slot-open";
export const SEARCH_PENDING_CLASS = "is-pending";
export const SEARCH_VISIBLE_CLASS = "is-visible";
export const SEARCH_FADING_IN_CLASS = "is-fading-in";

// Animation phase keys for searchAnimationPlay
export const SEARCH_PHASE_START = "animateforstart";
export const SEARCH_PHASE_FADE_IN = "animateforfadein";
export const SEARCH_PHASE_STATIC = "animateforstatic";

// CSS timing variables
export const SEARCH_VAR_FADE_IN_MS = "--search-fade-in-ms";
export const SEARCH_VAR_SLOT_OPEN_MS = "--search-slot-open-ms";
export const SEARCH_VAR_SLOT_GAP = "--search-slot-gap";
export const SEARCH_VAR_BLOCK_HEIGHT = "--codes-search-block-height";
export const SEARCH_VAR_FRAME_BODY_TOP = "--frame-animate-for-search-body-top";

export const SEARCH_ANIMATION_TIMEOUT_BUFFER_MS = 32;
export const SEARCH_REFERENCE_MESSAGE_LINES = 2;
