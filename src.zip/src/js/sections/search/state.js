let searchState = {
  isAuthVisible: false,
  isRevealed: false,
};

/** Returns a snapshot of the search section state. */
export function searchStateGet() {
  return {
    isAuthVisible: searchState.isAuthVisible,
    isRevealed: searchState.isRevealed,
  };
}

/** Updates search section state fields supplied by the caller. */
export function searchStateSet(next) {
  searchState = {
    isAuthVisible:
      typeof next.isAuthVisible === "boolean"
        ? next.isAuthVisible
        : searchState.isAuthVisible,
    isRevealed:
      typeof next.isRevealed === "boolean" ? next.isRevealed : searchState.isRevealed,
  };
}
