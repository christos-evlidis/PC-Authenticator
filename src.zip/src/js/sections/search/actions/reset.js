import { searchFilterReset } from "./filter.js";
import { searchStateSet } from "../state.js";
import { SEARCH_INPUT_SELECTOR } from "../constants.js";
import { SEARCH_PENDING_CLASS } from "../constants.js";
import { SEARCH_ROOT_SELECTOR } from "../constants.js";
import { SEARCH_SLOT_OPEN_CLASS } from "../constants.js";
import { SEARCH_VISIBLE_CLASS } from "../constants.js";
import { SEARCH_FADING_IN_CLASS } from "../constants.js";
import { SEARCH_HIDDEN_CLASS } from "../constants.js";

/** Clears search input, filter state, and reveal classes. */
export function searchReset() {
  const search = document.querySelector(SEARCH_ROOT_SELECTOR);
  const input = document.querySelector(SEARCH_INPUT_SELECTOR);

  if (input) {
    input.value = "";
  }

  search?.classList.remove(
    SEARCH_SLOT_OPEN_CLASS,
    SEARCH_VISIBLE_CLASS,
    SEARCH_PENDING_CLASS,
    SEARCH_FADING_IN_CLASS,
  );
  searchFilterReset();
  searchStateSet({ isRevealed: false });
}
