import { HEADER_ANIMATE_FOR_FADE_IN_CLASS } from "../constants.js";
import { HEADER_ANIMATE_FOR_FADE_IN_HIDDEN_CLASS } from "../constants.js";
import { HEADER_ROOT_SELECTOR } from "../constants.js";

/** Removes fade-in classes after the static phase. */
export function headerAnimateForStatic() {
  const header = document.querySelector(HEADER_ROOT_SELECTOR);

  header?.classList.remove(
    HEADER_ANIMATE_FOR_FADE_IN_HIDDEN_CLASS,
    HEADER_ANIMATE_FOR_FADE_IN_CLASS,
  );
}
