import { headerAnimateForContent } from "./content.js";
import { headerAnimateForFadeIn } from "./fade-in.js";
import { headerAnimateForStatic } from "./static.js";
import { headerAnimateForStart } from "./start.js";
import { HEADER_PHASE_CONTENT } from "../constants.js";
import { HEADER_PHASE_FADE_IN } from "../constants.js";
import { HEADER_PHASE_STATIC } from "../constants.js";
import { HEADER_PHASE_START } from "../constants.js";

/** Dispatches a header animation phase by key. */
export async function headerAnimationPlay(phase) {
  if (phase === HEADER_PHASE_START) {
    headerAnimateForStart();
    return;
  }

  if (phase === HEADER_PHASE_FADE_IN) {
    await headerAnimateForFadeIn();
    return;
  }

  if (phase === HEADER_PHASE_CONTENT) {
    await headerAnimateForContent();
    return;
  }

  if (phase === HEADER_PHASE_STATIC) {
    headerAnimateForStatic();
  }
}
