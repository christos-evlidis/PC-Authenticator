import { headerReset } from "../actions/reset.js";

/** Resets header chrome to the pre-start hidden state. */
export function headerAnimateForStart() {
  headerReset();
}
