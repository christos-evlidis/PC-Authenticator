import { bodyAnimationStatic } from "../body/body-animation.js";
import { bodyApply } from "../body/body-render.js";
import { headerActionsEnabledSet } from "../header/header-render.js";
import { headerApply } from "../header/header-render.js";
import { cross } from "../section-cross.js";

/** Syncs header, body, and related section bindings for the signed-in state. */
export function setAuthState(isLoggedIn, options = {}) {
  const {
    skipSignedOutReveal = false,
    bodyStaticReveal = false,
    accountNumber = null,
  } = options;

  headerApply(isLoggedIn, accountNumber);
  bodyApply(isLoggedIn, accountNumber);

  if (!isLoggedIn && (bodyStaticReveal || !skipSignedOutReveal)) {
    bodyAnimationStatic();
  }

  cross.codes.setSearchAuthVisible(isLoggedIn);

  if (isLoggedIn) {
    cross.manualSetup.refreshBindings();
  }
}

/** Syncs signed-in chrome from storage. */
export async function refreshAuthState(options = {}) {
  const { skipSignedOutReveal = false, bodyStaticReveal = false } = options;
  const { accountNumber } = await chrome.storage.local.get(["accountNumber"]);
  const isLoggedIn = Boolean(accountNumber);

  setAuthState(isLoggedIn, {
    skipSignedOutReveal,
    bodyStaticReveal,
    accountNumber: accountNumber ?? null,
  });

  if (!isLoggedIn) {
    cross.codes.clear();
  }
}

export { headerActionsEnabledSet as setHeaderActionsEnabled };
