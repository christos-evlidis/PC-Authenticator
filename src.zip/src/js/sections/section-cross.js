/**
 * Internal cross-section API links. Wired once by section-index before bootstrap.
 * Avoids circular imports between section domains.
 */
export const cross = {
  codes: null,
  userMenu: null,
  manualSetup: null,
  qrCodeSetup: null,
  reviewPrompt: null,
};
