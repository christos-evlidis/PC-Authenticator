import { ACCOUNT_COPY_BTN_SELECTOR } from "./user-menu-state.js";
import { ACCOUNT_DOWNLOAD_BTN_SELECTOR } from "./user-menu-state.js";
import { ACCOUNT_FORM_SELECTOR } from "./user-menu-state.js";
import { ACCOUNT_INPUT_SELECTOR } from "./user-menu-state.js";

export const ACCOUNT_ACTION_FEEDBACK_MS = 1500;
export const ACCOUNT_ICON_COPY = "fa-copy";
export const ACCOUNT_ICON_DOWNLOAD = "fa-download";
export const ACCOUNT_ICON_CHECK = "fa-check";

export function setAccountInputValue(accountNumber) {
  const input = document.querySelector(ACCOUNT_INPUT_SELECTOR);
  if (input) {
    input.value = accountNumber ?? "";
  }
}

export function getAccountNumber() {
  return document.querySelector(ACCOUNT_INPUT_SELECTOR)?.value.trim() ?? "";
}

function setAccountActionButtonIcon(button, iconClass) {
  const icon = button?.querySelector("i");
  if (icon) {
    icon.className = `fas ${iconClass}`;
  }
}

function showAccountActionFeedback(button, originalIconClass) {
  if (!button || button.disabled) return;

  button.disabled = true;
  button.classList.add("is-success");
  setAccountActionButtonIcon(button, ACCOUNT_ICON_CHECK);

  window.setTimeout(() => {
    setAccountActionButtonIcon(button, originalIconClass);
    button.classList.remove("is-success");
    button.disabled = false;
  }, ACCOUNT_ACTION_FEEDBACK_MS);
}

export async function copyAccountNumber() {
  const accountNumber = getAccountNumber();
  if (!accountNumber) return false;

  await navigator.clipboard.writeText(accountNumber);
  return true;
}

export function downloadAccountNumber() {
  const accountNumber = getAccountNumber();
  if (!accountNumber) return false;

  const blob = new Blob([`${accountNumber}\n`], {
    type: "text/plain;charset=utf-8",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "pc-authenticator-account-number.txt";
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  return true;
}

function handleAccountFormClick(event) {
  const copyBtn = event.target.closest(ACCOUNT_COPY_BTN_SELECTOR);
  if (copyBtn) {
    event.preventDefault();
    event.stopPropagation();
    void copyAccountNumber().then((copied) => {
      if (copied) {
        showAccountActionFeedback(copyBtn, ACCOUNT_ICON_COPY);
      }
    });
    return;
  }

  const downloadBtn = event.target.closest(ACCOUNT_DOWNLOAD_BTN_SELECTOR);
  if (downloadBtn) {
    event.preventDefault();
    event.stopPropagation();
    if (downloadAccountNumber()) {
      showAccountActionFeedback(downloadBtn, ACCOUNT_ICON_DOWNLOAD);
    }
  }
}

export function initAccountActions() {
  document
    .querySelector(ACCOUNT_FORM_SELECTOR)
    ?.addEventListener("click", handleAccountFormClick);
}
