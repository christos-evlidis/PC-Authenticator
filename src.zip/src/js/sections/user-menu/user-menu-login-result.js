import { cross } from "../section-cross.js";
import { prepareSignedOutMenuViews } from "./user-menu-auth.js";
import { prepareAuthenticatedThumbSelector } from "./user-menu-tabs.js";
import { showAuthenticatedThumbSelectorInstant } from "./user-menu-tabs.js";
import { getUserMenuPanel } from "./user-menu-state.js";
import { LOGIN_ERROR_SELECTOR } from "./user-menu-state.js";
import { LOGIN_LOADING_SELECTOR } from "./user-menu-state.js";
import { LOGIN_SUCCESS_SELECTOR } from "./user-menu-state.js";

export function hideLoginStatusIcon(selector) {
  const icon = document.querySelector(selector);
  if (!icon) return;

  icon.classList.add("hidden");
  icon.classList.remove("is-shown", "is-hiding", "is-animating", "is-drawn");
}

export async function playLoginResultIcon(selector, options = {}) {
  const { fadeAppChrome = false } = options;

  hideLoginStatusIcon(LOGIN_LOADING_SELECTOR);

  if (fadeAppChrome) {
    await cross.codes.applyPostLogoutChrome();
  }

  hideLoginStatusIcon(
    selector === LOGIN_SUCCESS_SELECTOR
      ? LOGIN_ERROR_SELECTOR
      : LOGIN_SUCCESS_SELECTOR,
  );
}

export async function revealAuthChrome(isSuccess) {
  const panel = getUserMenuPanel();

  panel?.classList.remove(
    "is-fading-auth-ui",
    "is-login-flow",
    "is-chrome-hidden",
    "is-chrome-preparing",
    "is-chrome-visible",
    "is-panel-immersive",
    "is-signed-out-reveal",
  );

  document
    .querySelector(".user-menu-body")
    ?.classList.remove("is-expanded", "is-loader-active");

  if (isSuccess) {
    showAuthenticatedThumbSelectorInstant();
  } else {
    prepareSignedOutMenuViews();
    panel?.classList.remove("is-authenticated");
    panel?.classList.add("is-signed-out-reveal");
  }
}

export async function shrinkLoginBody() {}
