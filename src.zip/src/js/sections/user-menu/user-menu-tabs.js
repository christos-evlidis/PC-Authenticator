import { THEME_DARK } from "../../theme/theme.js";
import { THEME_LIGHT } from "../../theme/theme.js";
import { applyTheme } from "../../theme/theme.js";
import { persistTheme } from "../../theme/theme.js";
import { resolveTheme } from "../../theme/theme.js";
import { AUTH_THUMB_BTN_SELECTOR } from "./user-menu-state.js";
import { AUTH_THUMB_TRACK_SELECTOR } from "./user-menu-state.js";
import { getIsLoginSequenceRunning } from "./user-menu-state.js";
import { getIsUserMenuTabAnimating } from "./user-menu-state.js";
import { getUserMenuPanel } from "./user-menu-state.js";
import { THEME_THUMB_BTN_SELECTOR } from "./user-menu-state.js";
import { THEME_THUMB_TRACK_SELECTOR } from "./user-menu-state.js";
import { USER_MENU_BODY_SELECTOR } from "./user-menu-state.js";
import { USER_MENU_SIGN_IN_VIEW_SELECTOR } from "./user-menu-state.js";
import { USER_MENU_SIGN_UP_VIEW_SELECTOR } from "./user-menu-state.js";
import { VIEW_SIGN_IN } from "./user-menu-state.js";
import { VIEW_SIGN_UP } from "./user-menu-state.js";

export function updateAuthThumbSelector(view) {
  const track = document.querySelector(AUTH_THUMB_TRACK_SELECTOR);
  const buttons = document.querySelectorAll(AUTH_THUMB_BTN_SELECTOR);
  const isSignIn = view === VIEW_SIGN_IN;

  if (track) {
    track.classList.toggle("is-sign-in", isSignIn);
    track.classList.toggle("is-sign-up", !isSignIn);
  }

  buttons.forEach((btn) => {
    btn.classList.toggle("is-active", btn.dataset.view === view);
  });
}

export async function setUserMenuTab(view, options = {}) {
  const signInView = document.querySelector(USER_MENU_SIGN_IN_VIEW_SELECTOR);
  const signUpView = document.querySelector(USER_MENU_SIGN_UP_VIEW_SELECTOR);

  const isSignIn = view === VIEW_SIGN_IN;
  const incoming = isSignIn ? signInView : signUpView;
  const outgoing = isSignIn ? signUpView : signInView;

  if (!incoming || !outgoing) return;
  if (getIsLoginSequenceRunning()) return;

  updateAuthThumbSelector(view);
  incoming.classList.add("is-active");
  outgoing.classList.remove("is-active");
}

export function updateThemeThumbSelector(theme) {
  const track = document.querySelector(THEME_THUMB_TRACK_SELECTOR);
  const buttons = document.querySelectorAll(THEME_THUMB_BTN_SELECTOR);
  const isLight = theme === THEME_LIGHT;

  if (track) {
    track.classList.toggle("is-light", isLight);
    track.classList.toggle("is-dark", !isLight);
  }

  buttons.forEach((btn) => {
    btn.classList.toggle("is-active", btn.dataset.theme === theme);
  });
}

export async function setUserMenuTheme(theme, options = {}) {
  const { instant = false } = options;
  const resolved = resolveTheme(theme);

  if (!resolved) {
    return;
  }

  if (getIsUserMenuTabAnimating() || getIsLoginSequenceRunning()) {
    return;
  }

  if (instant) {
    applyTheme(resolved, { instant: true });

    await chrome.storage.local.set({ theme: resolved });
  } else {
    await persistTheme(resolved);
  }

  updateThemeThumbSelector(resolved);
}

export function prepareAuthenticatedThumbSelector() {
  const panel = getUserMenuPanel();
  const authThumb = document.querySelector(".thumb-selector--auth");
  const themeThumb = document.querySelector(".thumb-selector--theme");

  panel?.classList.add("is-authenticated");
  authThumb?.classList.add("hidden");
  themeThumb?.classList.remove("hidden");
  themeThumb?.classList.remove("is-visible");
}

export function prepareSignedOutThumbSelector() {
  const authThumb = document.querySelector(".thumb-selector--auth");
  const themeThumb = document.querySelector(".thumb-selector--theme");

  authThumb?.classList.remove("hidden");
  themeThumb?.classList.add("hidden");
  themeThumb?.classList.remove("is-visible");
}

export function showAuthenticatedThumbSelectorInstant() {
  prepareAuthenticatedThumbSelector();
  document.querySelector(".thumb-selector--theme")?.classList.add("is-visible");
}

export function initUserMenuTabs() {
  const buttons = document.querySelectorAll(AUTH_THUMB_BTN_SELECTOR);

  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const view = btn.dataset.view;
      if (view === VIEW_SIGN_IN || view === VIEW_SIGN_UP) {
        void setUserMenuTab(view);
      }
    });
  });

  void setUserMenuTab(VIEW_SIGN_IN, { instant: true });
}

export function initThemeTabs() {
  const buttons = document.querySelectorAll(THEME_THUMB_BTN_SELECTOR);

  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const theme = btn.dataset.theme;
      if (theme === THEME_LIGHT || theme === THEME_DARK) {
        void setUserMenuTheme(theme);
      }
    });
  });
}
