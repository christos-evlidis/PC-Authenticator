import { accountSync } from "../../accounts/account-index.js";
import { cross } from "../section-cross.js";
import { setAccountInputValue } from "./user-menu-account.js";
import { prepareSignedOutMenuViews } from "./user-menu-auth.js";
import { prepareSignedOutThumbSelector } from "./user-menu-tabs.js";
import { setUserMenuMainView } from "./user-menu-auth.js";
import {
  hideLoginStatusIcon,
  playLoginResultIcon,
  revealAuthChrome,
} from "./user-menu-login-result.js";
import { MAIN_VIEW_ACCOUNT } from "./user-menu-state.js";
import { getIsLoginSequenceRunning } from "./user-menu-state.js";
import { getUserMenuPanel } from "./user-menu-state.js";
import { LOGIN_ERROR_SELECTOR } from "./user-menu-state.js";
import { LOGIN_LOADING_SELECTOR } from "./user-menu-state.js";
import { LOGIN_SUCCESS_SELECTOR } from "./user-menu-state.js";
import { setAuthFlowLock } from "./user-menu-state.js";
import { setIsLoginSequenceRunning } from "./user-menu-state.js";

export async function resetLoginSequence() {
  const panel = getUserMenuPanel();
  const menuBody = document.querySelector(".user-menu-body");

  panel?.classList.remove(
    "is-fading-auth-ui",
    "is-login-flow",
    "is-chrome-hidden",
    "is-chrome-preparing",
    "is-chrome-visible",
    "is-panel-immersive",
    "is-signed-out-reveal",
  );
  menuBody?.classList.remove("is-expanded", "is-loader-active");
  hideLoginStatusIcon(LOGIN_LOADING_SELECTOR);
  hideLoginStatusIcon(LOGIN_SUCCESS_SELECTOR);
  hideLoginStatusIcon(LOGIN_ERROR_SELECTOR);

  setIsLoginSequenceRunning(false);
  setAuthFlowLock(false);
  prepareSignedOutThumbSelector();
}

export async function playAuthFlowSequence(apiPromise, options = {}) {
  const {
    revealAuthenticated = true,
    onAuthSuccess = null,
    fadeAppOnSuccess = false,
  } = options;

  if (getIsLoginSequenceRunning()) {
    throw new Error("Login sequence is already running.");
  }

  setIsLoginSequenceRunning(true);
  setAuthFlowLock(true);

  try {
    const apiResult = await apiPromise;

    if (onAuthSuccess) {
      await onAuthSuccess(apiResult);
    }

    await playLoginResultIcon(LOGIN_SUCCESS_SELECTOR, {
      fadeAppChrome: fadeAppOnSuccess,
    });
    await revealAuthChrome(revealAuthenticated);

    return apiResult;
  } finally {
    hideLoginStatusIcon(LOGIN_LOADING_SELECTOR);
    setIsLoginSequenceRunning(false);
    setAuthFlowLock(false);
  }
}

export async function playLogoutSequence(applySignedOutState) {
  await playAuthFlowSequence(Promise.resolve(), {
    revealAuthenticated: false,
    fadeAppOnSuccess: true,
    onAuthSuccess: async () => {
      await chrome.storage.local.remove(["accountNumber"]);
    },
  });

  await applySignedOutState();
}

export async function playLoginSuccessSequence(apiPromise, options = {}) {
  const { accountNumber: accountNumberOption } = options;

  const apiResult = await playAuthFlowSequence(apiPromise, {
    revealAuthenticated: true,
    onAuthSuccess: async (result) => {
      const payload = result?.value ?? result;
      const accountNumber =
        accountNumberOption ||
        (typeof payload === "string" ? payload : payload?.accountNumber) ||
        "";

      if (!accountNumber) {
        console.warn(
          "[user-menu-login-sequence] auth succeeded but no account number in result",
          result,
        );
        return;
      }

      setAccountInputValue(accountNumber);
      await chrome.storage.local.set({ accountNumber });
      setUserMenuMainView(MAIN_VIEW_ACCOUNT, { instant: true });
      const accounts = await accountSync(accountNumber);
      cross.codes.stagePostLoginReveal(accounts);
      cross.codes.preparePostLoginReveal();
    },
  });

  return apiResult;
}
