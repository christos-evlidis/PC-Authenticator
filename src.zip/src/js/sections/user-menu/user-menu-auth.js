import { accountsClear } from "../../accounts/account-index.js";
import { accountCreate } from "../../accounts/account-index.js";
import { accountVerify } from "../../accounts/account-index.js";
import { readLocalTheme } from "../../theme/theme.js";
import { syncThemeFromChromeStorage } from "../../theme/theme.js";
import { cross } from "../section-cross.js";
import { setAccountInputValue } from "./user-menu-account.js";
import { MAIN_VIEW_ACCOUNT } from "./user-menu-state.js";
import { MAIN_VIEW_AUTH } from "./user-menu-state.js";
import { USER_MENU_ACCOUNT_VIEW_SELECTOR } from "./user-menu-state.js";
import { USER_MENU_AUTH_VIEW_SELECTOR } from "./user-menu-state.js";
import { USER_MENU_BODY_SELECTOR } from "./user-menu-state.js";
import { VIEW_SIGN_IN } from "./user-menu-state.js";
import { getUserMenuPanel } from "./user-menu-state.js";
import { prepareSignedOutThumbSelector } from "./user-menu-tabs.js";
import { setUserMenuTab } from "./user-menu-tabs.js";
import { showAuthenticatedThumbSelectorInstant } from "./user-menu-tabs.js";
import { updateThemeThumbSelector } from "./user-menu-tabs.js";

export function setUserMenuMainView(view, options = {}) {
  const { instant = false } = options;
  const authView = document.querySelector(USER_MENU_AUTH_VIEW_SELECTOR);
  const accountView = document.querySelector(USER_MENU_ACCOUNT_VIEW_SELECTOR);
  const menuBody = document.querySelector(USER_MENU_BODY_SELECTOR);

  const showAccount = view === MAIN_VIEW_ACCOUNT;
  const incoming = showAccount ? accountView : authView;
  const outgoing = showAccount ? authView : accountView;

  if (instant) {
    menuBody.classList.add("is-main-view-instant");
    incoming.classList.add("is-active");
    outgoing.classList.remove("is-active");
    menuBody.classList.remove("is-main-view-instant");
  }
}

export function prepareSignedOutMenuViews() {
  const signInInput = document.querySelector(".sign-in-form__input");

  signInInput.value = "";
  setAccountInputValue("");
  prepareSignedOutThumbSelector();
  setUserMenuMainView(MAIN_VIEW_AUTH, { instant: true });
  void setUserMenuTab(VIEW_SIGN_IN, { instant: true });
}

export function applyAuthenticatedState(accountNumber) {
  setAccountInputValue(accountNumber);
  setUserMenuMainView(MAIN_VIEW_ACCOUNT, { instant: true });
  showAuthenticatedThumbSelectorInstant();
}

export async function applySignedOutState() {
  const panel = getUserMenuPanel();

  cross.codes.clear();
  await accountsClear();
  panel.classList.remove("is-authenticated");
  prepareSignedOutMenuViews();
}

export function initSignInForm(playLoginSuccessSequence) {
  const form = document.querySelector(".sign-in-form");
  const input = document.querySelector(".sign-in-form__input");

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const accountNumber = input.value.trim();

    if (accountNumber.length === 0) {
      return;
    }

    const verifyPromise = accountVerify(accountNumber);
    await playLoginSuccessSequence(verifyPromise, { accountNumber });
  });
}

export function initSignUpForm(playLoginSuccessSequence) {
  const submitBtn = document.querySelector(".sign-up-form__submit");

  submitBtn.addEventListener("click", async () => {
    const createPromise = accountCreate().then((accountNumber) => ({
      accountNumber,
    }));
    await playLoginSuccessSequence(createPromise);
  });
}

export async function initAuthenticatedMenuState() {
  const { accountNumber } = await chrome.storage.local.get(["accountNumber"]);
  const resolvedTheme = await syncThemeFromChromeStorage();

  updateThemeThumbSelector(resolvedTheme);

  if (accountNumber) {
    applyAuthenticatedState(accountNumber);
  } else {
    await applySignedOutState();
  }
}

export async function handleLogout({ playLogoutSequence, resetLoginSequence }) {
  const { getIsLoginSequenceRunning } = await import("./user-menu-state.js");
  if (getIsLoginSequenceRunning()) {
    return;
  }

  await playLogoutSequence();
  cross.codes.refreshAuthState();
}
