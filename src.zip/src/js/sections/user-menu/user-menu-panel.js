import { cross } from "../section-cross.js";
import { BODY_BLUR_CLASS } from "./user-menu-state.js";
import { getUserMenuButtons } from "./user-menu-state.js";
import { getIsLoginSequenceRunning } from "./user-menu-state.js";
import { getUserMenuPanel } from "./user-menu-state.js";
import { getUserMenuSection } from "./user-menu-state.js";
import { isUserMenuActive } from "./user-menu-state.js";
import { USER_MENU_BACKDROP_SELECTOR } from "./user-menu-state.js";
import { USER_MENU_CLOSE_BTN_SELECTOR } from "./user-menu-state.js";

async function closeOtherOverlays() {
  if (cross.manualSetup.isActive()) {
    await cross.manualSetup.close();
  }
}

export async function openUserMenu() {
  if (getIsLoginSequenceRunning()) return;

  const section = getUserMenuSection();
  if (!section || isUserMenuActive()) return;

  await closeOtherOverlays();

  section.classList.add("is-active", "is-panel-open");
  document.body.classList.add(BODY_BLUR_CLASS);
  getUserMenuButtons().forEach((btn) => btn.classList.add("is-active"));
}

export async function closeUserMenu() {
  if (getIsLoginSequenceRunning()) return;

  const section = getUserMenuSection();
  if (!section || !isUserMenuActive()) return;

  section.classList.remove("is-panel-open", "is-active");
  document.body.classList.remove(BODY_BLUR_CLASS);
  getUserMenuButtons().forEach((btn) => btn.classList.remove("is-active"));

  const { accountNumber } = await chrome.storage.local.get(["accountNumber"]);

  if (accountNumber && cross.codes.hasPendingPostLoginReveal()) {
    await cross.codes.playPostLoginReveal();
  }
}

export function toggleUserMenu() {
  if (getIsLoginSequenceRunning()) return;

  if (isUserMenuActive()) {
    void closeUserMenu();
  } else {
    void openUserMenu();
  }
}

export function initUserMenuPanel() {
  const closeBtn = document.querySelector(USER_MENU_CLOSE_BTN_SELECTOR);
  const backdrop = document.querySelector(USER_MENU_BACKDROP_SELECTOR);
  const panel = getUserMenuPanel();

  getUserMenuButtons().forEach((btn) => {
    btn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      toggleUserMenu();
    });
  });

  closeBtn?.addEventListener("click", (event) => {
    event.stopPropagation();
    void closeUserMenu();
  });

  backdrop?.addEventListener("click", () => {
    void closeUserMenu();
  });

  panel?.addEventListener("click", (event) => {
    event.stopPropagation();
  });
}
