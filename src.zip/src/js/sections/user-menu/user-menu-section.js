import { initAccountActions } from "./user-menu-account.js";
import { applyAuthenticatedState } from "./user-menu-auth.js";
import { applySignedOutState } from "./user-menu-auth.js";
import { handleLogout } from "./user-menu-auth.js";
import { initAuthenticatedMenuState } from "./user-menu-auth.js";
import { initSignInForm } from "./user-menu-auth.js";
import { initSignUpForm } from "./user-menu-auth.js";
import { playAuthFlowSequence } from "./user-menu-login-sequence.js";
import { playLoginSuccessSequence } from "./user-menu-login-sequence.js";
import { playLogoutSequence } from "./user-menu-login-sequence.js";
import { resetLoginSequence } from "./user-menu-login-sequence.js";
import { closeUserMenu } from "./user-menu-panel.js";
import { initUserMenuPanel } from "./user-menu-panel.js";
import { openUserMenu } from "./user-menu-panel.js";
import { toggleUserMenu } from "./user-menu-panel.js";
import { initThemeTabs } from "./user-menu-tabs.js";
import { initUserMenuTabs } from "./user-menu-tabs.js";
import { setUserMenuTab } from "./user-menu-tabs.js";
import { setUserMenuTheme } from "./user-menu-tabs.js";
import { LOGOUT_BTN_SELECTOR } from "./user-menu-state.js";
import { isUserMenuActive } from "./user-menu-state.js";

function initUserMenu() {
  initUserMenuPanel();
  document.querySelector(LOGOUT_BTN_SELECTOR)?.addEventListener("click", () => {
    void handleLogout({
      playLogoutSequence: () => playLogoutSequence(applySignedOutState),
      resetLoginSequence,
    });
  });
  initAccountActions();
  initUserMenuTabs();
  initThemeTabs();
  initSignInForm(playLoginSuccessSequence);
  initSignUpForm(playLoginSuccessSequence);
  void initAuthenticatedMenuState();
}

export const userMenuSection = {
  init: initUserMenu,
  open: openUserMenu,
  close: closeUserMenu,
  toggle: toggleUserMenu,
  isActive: isUserMenuActive,
  setTab: setUserMenuTab,
  setTheme: setUserMenuTheme,
  playLoginSuccessSequence,
  playLogoutSequence: () => playLogoutSequence(applySignedOutState),
  resetLoginSequence,
  applyAuthenticatedState,
  applySignedOutState,
  logout: () =>
    handleLogout({
      playLogoutSequence: () => playLogoutSequence(applySignedOutState),
      resetLoginSequence,
    }),
};

export { initUserMenu };
export { playAuthFlowSequence };
