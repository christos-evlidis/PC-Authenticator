import { UtilsAnimation } from "../../utils/utility-animation.js";

export const USER_MENU_SECTION_SELECTOR = ".user-menu-section";
export const USER_MENU_BTN_SELECTOR = ".user-menu-btn";
export const USER_MENU_CLOSE_BTN_SELECTOR = ".user-menu-close-btn";
export const USER_MENU_BACKDROP_SELECTOR = ".user-menu-backdrop";
export const USER_MENU_PANEL_SELECTOR = ".user-menu-panel";
export const BLUR_TARGET_SELECTOR = ".extension-frame > .app-header";
export const AUTH_THUMB_TRACK_SELECTOR = ".thumb-selector__track--auth";
export const AUTH_THUMB_BTN_SELECTOR =
  ".thumb-selector--auth .thumb-selector__btn";
export const THEME_THUMB_TRACK_SELECTOR = ".thumb-selector__track--theme";
export const THEME_THUMB_BTN_SELECTOR =
  ".thumb-selector--theme .thumb-selector__btn";
export const USER_MENU_BODY_SELECTOR = ".user-menu-body";
export const USER_MENU_AUTH_VIEW_SELECTOR =
  ".user-menu-body__views > .user-menu-auth-view";
export const USER_MENU_ACCOUNT_VIEW_SELECTOR =
  ".user-menu-body__views > .user-menu-account-view";
export const USER_MENU_SIGN_IN_VIEW_SELECTOR =
  ".user-menu-auth-view__tabs > .sign-in-view";
export const USER_MENU_SIGN_UP_VIEW_SELECTOR =
  ".user-menu-auth-view__tabs > .sign-up-view";
export const ACCOUNT_FORM_SELECTOR = ".account-form";
export const ACCOUNT_INPUT_SELECTOR = ".account-form__input";
export const ACCOUNT_COPY_BTN_SELECTOR = ".account-form__copy-btn";
export const ACCOUNT_DOWNLOAD_BTN_SELECTOR = ".account-form__download-btn";
export const LOGOUT_BTN_SELECTOR = ".account-form__logout";
export const LOGIN_LOADING_SELECTOR = ".login-status--loading";
export const LOGIN_SUCCESS_SELECTOR = ".login-status--success";
export const LOGIN_ERROR_SELECTOR = ".login-status--error";

export const BODY_BLUR_CLASS = "is-user-menu-blurred";
export const BODY_AUTH_FLOW_LOCK_CLASS = "is-auth-flow-locked";

export const VIEW_SIGN_IN = "sign-in";
export const VIEW_SIGN_UP = "sign-up";
export const MAIN_VIEW_AUTH = "auth";
export const MAIN_VIEW_ACCOUNT = "account";

let userMenuAnimationToken = 0;
export let isUserMenuTabAnimating = false;
export let isLoginSequenceRunning = false;

export function bumpUserMenuAnimationToken() {
  userMenuAnimationToken += 1;
  return userMenuAnimationToken;
}

export function isUserMenuAnimationCurrent(token) {
  return token === userMenuAnimationToken;
}

export function setAuthFlowLock(isLocked) {
  document.body.classList.toggle(BODY_AUTH_FLOW_LOCK_CLASS, isLocked);
}

export function getIsUserMenuTabAnimating() {
  return isUserMenuTabAnimating;
}

export function setUserMenuTabAnimating(value) {
  isUserMenuTabAnimating = value;
}

export function getIsLoginSequenceRunning() {
  return isLoginSequenceRunning;
}

export function setIsLoginSequenceRunning(value) {
  isLoginSequenceRunning = value;
}

export function getUserMenuButtons() {
  return document.querySelectorAll(USER_MENU_BTN_SELECTOR);
}

export function getUserMenuSection() {
  return document.querySelector(USER_MENU_SECTION_SELECTOR);
}

export function getUserMenuPanel() {
  return document.querySelector(USER_MENU_PANEL_SELECTOR);
}

export function getBlurTarget() {
  return document.querySelector(BLUR_TARGET_SELECTOR);
}

export function isUserMenuActive() {
  return getUserMenuSection()?.classList.contains("is-active") ?? false;
}

export function getBlurDurationMs() {
  return UtilsAnimation.getCssDurationMs("--user-menu-blur-duration", 250);
}

export function getSlideDurationMs() {
  return UtilsAnimation.getCssDurationMs("--user-menu-slide-duration", 250);
}

export function getTabDurationMs() {
  return UtilsAnimation.getCssDurationMs("--user-menu-tab-duration", 350);
}

export function getLoginUiFadeMs() {
  return UtilsAnimation.getCssDurationMs("--login-ui-fade-duration", 350);
}

export function getLoginBodyExpandMs() {
  return UtilsAnimation.getCssDurationMs("--login-body-expand-duration", 250);
}

export function getLoginPanelImmersiveMs() {
  return UtilsAnimation.getCssDurationMs(
    "--login-panel-immersive-duration",
    250,
  );
}

export function getLoginDotsFadeInMs() {
  return UtilsAnimation.getCssDurationMs("--login-dots-fade-in-duration", 250);
}

export function getLoginDotsVisibleMs() {
  return UtilsAnimation.getCssDurationMs("--login-dots-visible-duration", 2000);
}

export function getLoginDotsFadeOutMs() {
  return UtilsAnimation.getCssDurationMs("--login-dots-fade-out-duration", 250);
}

export function getLoginResultFadeInMs() {
  return UtilsAnimation.getCssDurationMs(
    "--login-result-fade-in-duration",
    250,
  );
}

export function getLoginCheckDrawMs() {
  return UtilsAnimation.getCssDurationMs("--login-check-draw-duration", 500);
}

export function getLoginCheckFadeOutMs() {
  return UtilsAnimation.getCssDurationMs(
    "--login-check-fade-out-duration",
    250,
  );
}

export function getLoginIconDrawTotalMs() {
  const drawMs = getLoginCheckDrawMs();
  const markDelayMs = drawMs * 0.45;
  return drawMs + markDelayMs;
}
