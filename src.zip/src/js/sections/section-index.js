import { cross } from "./section-cross.js";
import { codesSection } from "./codes/codes-section.js";
import { initCodes } from "./codes/codes-section.js";
import { initOnLoad } from "./codes/codes-section.js";
import { initManualSetup } from "./manual-setup/manual-setup-section.js";
import { manualSetupSection } from "./manual-setup/manual-setup-section.js";
import { initQrCodeSetup } from "./qr-code-setup/qr-code-setup-section.js";
import { qrCodeSetupSection } from "./qr-code-setup/qr-code-setup-section.js";
import { initReviewPrompt } from "./review-prompt/review-prompt-section.js";
import { reviewPromptSection } from "./review-prompt/review-prompt-section.js";
import { initUserMenu } from "./user-menu/user-menu-section.js";
import { userMenuSection } from "./user-menu/user-menu-section.js";

/** Wires cross-section APIs before auth or section load runs. */
export function registerSections() {
  cross.codes = codesSection;
  cross.userMenu = userMenuSection;
  cross.manualSetup = manualSetupSection;
  cross.qrCodeSetup = qrCodeSetupSection;
  cross.reviewPrompt = reviewPromptSection;
}

export function initSectionModules() {
  initReviewPrompt();
  initUserMenu();
  initManualSetup();
  initQrCodeSetup();
  initCodes();
}

export { initCodes };
export { initOnLoad };

export async function loadSections(skipIntroForQrResume = false) {
  await initOnLoad(skipIntroForQrResume);
}
