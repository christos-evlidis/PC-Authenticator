import { bodyAnimateForSearchBar } from "./search-bar.js";
import { bodyAnimateForSignedInContent } from "./signed-in-content.js";
import { bodyAnimateForSignedOutContent } from "./signed-out-content.js";
import { bodyAnimateForExtensionFrame } from "./extension-frame.js";
import { bodyAnimateForStatic } from "./static.js";
import { bodyAnimateForHeader } from "./header.js";
import { bodyAnimateForLogo } from "./logo.js";
import { bodyAnimateForStart } from "./start.js";
import { BODY_PHASE_EXTENSION_FRAME } from "../constants.js";
import { BODY_PHASE_STATIC } from "../constants.js";
import { BODY_PHASE_HEADER } from "../constants.js";
import { BODY_PHASE_LOGO } from "../constants.js";
import { BODY_PHASE_SEARCH_BAR } from "../constants.js";
import { BODY_PHASE_SIGNED_IN_CONTENT } from "../constants.js";
import { BODY_PHASE_SIGNED_OUT_CONTENT } from "../constants.js";
import { BODY_PHASE_START } from "../constants.js";

/** Dispatches a body animation phase by key. */
export async function bodyAnimationPlay(phase, options = {}) {
  if (phase === BODY_PHASE_START) {
    bodyAnimateForStart();
    return;
  }

  if (phase === BODY_PHASE_LOGO) {
    await bodyAnimateForLogo();
    return;
  }

  if (phase === BODY_PHASE_EXTENSION_FRAME) {
    await bodyAnimateForExtensionFrame();
    return;
  }

  if (phase === BODY_PHASE_HEADER) {
    await bodyAnimateForHeader();
    return;
  }

  if (phase === BODY_PHASE_SIGNED_OUT_CONTENT) {
    await bodyAnimateForSignedOutContent(options);
    return;
  }

  if (phase === BODY_PHASE_SIGNED_IN_CONTENT) {
    await bodyAnimateForSignedInContent(options);
    return;
  }

  if (phase === BODY_PHASE_SEARCH_BAR) {
    await bodyAnimateForSearchBar();
    return;
  }

  if (phase === BODY_PHASE_STATIC) {
    bodyAnimateForStatic();
  }
}
