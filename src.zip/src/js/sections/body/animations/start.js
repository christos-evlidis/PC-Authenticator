import { bodyReset } from "../actions/reset.js";
import { BODY_ACTIVE_CLASS } from "../constants.js";
import { BODY_ANIMATE_FOR_START_CLASS } from "../constants.js";
import { BODY_PENDING_CLASS } from "../constants.js";
import { BODY_ROOT_SELECTOR } from "../constants.js";
import { EXTENSION_FRAME_SELECTOR } from "../constants.js";

/** Prepares frame/body layout before bootstrap animations. */
export function bodyAnimateForStart() {
  bodyReset();

  const frame = document.querySelector(EXTENSION_FRAME_SELECTOR);
  const root = document.querySelector(BODY_ROOT_SELECTOR);

  frame?.classList.add(BODY_ANIMATE_FOR_START_CLASS);
  root?.classList.add(BODY_ANIMATE_FOR_START_CLASS);
  root?.classList.remove(BODY_ACTIVE_CLASS);
  root?.classList.add(BODY_PENDING_CLASS);
}
