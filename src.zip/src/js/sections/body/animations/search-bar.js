import { cssMs } from "../../../utils/utility-animation.js";
import { waitForNextFrame } from "../../../utils/utility-animation.js";
import { waitForTransitionEnd } from "../../../utils/utility-animation.js";
import { BODY_ANIMATE_FOR_SEARCH_BAR_CLASS } from "../constants.js";
import { BODY_ANIMATION_TIMEOUT_BUFFER_MS } from "../constants.js";
import { BODY_ROOT_SELECTOR } from "../constants.js";
import { BODY_VAR_SEARCH_BAR_INSET_MS } from "../constants.js";

/** Pushes the body down to make room for the search bar slot. */
export async function bodyAnimateForSearchBar() {
  const body = document.querySelector(BODY_ROOT_SELECTOR);
  const searchBarMs = cssMs(body, BODY_VAR_SEARCH_BAR_INSET_MS);

  if (!body) {
    return;
  }

  body.classList.add(BODY_ANIMATE_FOR_SEARCH_BAR_CLASS);
  await waitForNextFrame();
  await waitForTransitionEnd(
    body,
    "top",
    searchBarMs + BODY_ANIMATION_TIMEOUT_BUFFER_MS,
  );
}
