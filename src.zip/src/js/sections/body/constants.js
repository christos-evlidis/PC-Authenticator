// Selectors
export const BODY_ROOT_SELECTOR = ".app-body";
export const BODY_SIGNED_OUT_VIEW_SELECTOR = ".app-body__view--signed-out";
export const BODY_SIGNED_IN_VIEW_SELECTOR = ".app-body__view--signed-in";
export const BODY_CONTENT_SIGNED_OUT_SELECTOR = ".app-body__view--signed-out .app-body__content";
export const BODY_CONTENT_SIGNED_IN_SELECTOR = ".app-body__view--signed-in .app-body__content";
export const BODY_MESSAGE_STACK_SELECTOR = ".app-body__message-stack";
export const BODY_MESSAGE_SPACER_SELECTOR = ".app-body__message--spacer";
export const BODY_MESSAGE_DISPLAY_SELECTOR = ".app-body__message--display";
export const BODY_ICON_SELECTOR = ".app-body__icon";
export const BODY_LOGO_SELECTOR = ".app-body__logo";
export const EXTENSION_FRAME_SELECTOR = ".extension-frame";

// State classes
export const BODY_HIDDEN_CLASS = "is-hidden";
export const BODY_ACTIVE_CLASS = "is-active";
export const BODY_PENDING_CLASS = "is-pending";
export const BODY_RUNNING_CLASS = "is-running";
export const BODY_LOGO_FADING_CLASS = "is-logo-fading-out";
export const BODY_SIGNED_IN_ICON_POP_CLASS = "is-signed-in-icon-pop";
export const BODY_SIGNED_IN_TEXT_TYPE_CLASS = "is-signed-in-text-type";
export const BODY_SIGNED_OUT_ICON_POP_CLASS = "is-signed-out-icon-pop";
export const BODY_SIGNED_OUT_TEXT_TYPE_CLASS = "is-signed-out-text-type";
export const BODY_ANIMATE_FOR_START_CLASS = "is-animate-for-start";
export const BODY_ANIMATE_FOR_EXTENSION_FRAME_CLASS = "is-animate-for-extension-frame";
export const BODY_ANIMATE_FOR_HEADER_CLASS = "is-animate-for-header";
export const BODY_ANIMATE_FOR_SEARCH_BAR_CLASS = "is-animate-for-search-bar";
export const BODY_ANIMATE_FOR_LOGO_CLASS = "is-animate-for-logo";

// Copy
export const BODY_SIGNED_OUT_MESSAGE_TEXT = "To use the authenticator\nsign in or sign up.";
export const BODY_SIGNED_IN_EMPTY_MESSAGE_TEXT = "Add your first code.\nUse + or scan a QR code to get started.";

// Animation phase keys for bodyAnimationPlay
export const BODY_PHASE_START = "animateforstart";
export const BODY_PHASE_LOGO = "animateforlogo";
export const BODY_PHASE_EXTENSION_FRAME = "animateforextensionframe";
export const BODY_PHASE_HEADER = "animateforheader";
export const BODY_PHASE_SIGNED_OUT_CONTENT = "animateforsignedoutcontent";
export const BODY_PHASE_SIGNED_IN_CONTENT = "animateforsignedincontent";
export const BODY_PHASE_SEARCH_BAR = "animateforsearchbar";
export const BODY_PHASE_STATIC = "animateforstatic";

// CSS timing variables
export const BODY_VAR_SIGNED_OUT_ICON_POP_MS = "--body-signed-out-icon-pop-ms";
export const BODY_VAR_SIGNED_IN_ICON_POP_MS = "--body-signed-in-icon-pop-ms";
export const BODY_VAR_TEXT_TYPE_MS = "--body-text-type-ms";
export const BODY_VAR_LOGO_HOLD_MS = "--body-logo-hold-ms";
export const BODY_VAR_LOGO_FADE_MS = "--body-logo-fade-ms";
export const BODY_VAR_EXTENSION_FRAME_INSET_MS = "--body-extension-frame-inset-ms";
export const BODY_VAR_HEADER_INSET_MS = "--body-header-inset-ms";
export const BODY_VAR_SEARCH_BAR_INSET_MS = "--body-search-bar-inset-ms";

export const BODY_ANIMATION_TIMEOUT_BUFFER_MS = 32;
