import { themeApplyBodyLogo } from "../../../utils/utility-theme.js";
import { themeRead } from "../../../utils/utility-theme.js";
import { bodyAnimateForSignedInContent } from "../animations/signed-in-content.js";
import { bodyAnimateForSignedOutContent } from "../animations/signed-out-content.js";

/** Resets body content views to the pre-bootstrap hidden state. */
export function bodyReset() {
  themeApplyBodyLogo(themeRead());
  void bodyAnimateForSignedOutContent({ reset: true });
  void bodyAnimateForSignedInContent({ reset: true });
}
