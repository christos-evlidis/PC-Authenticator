import { VAR_BUFFER_MS, VAR_POP_MS, VAR_TYPE_MS } from "../../../utils/motion-const.js";

// Layout measurement anchors.
export const EXTENSION_FRAME_SELECTOR = ".extension-frame";

// Shell selectors.
export const BODY_ROOT_SELECTOR = ".app-body";
export const BODY_VIEW_SELECTOR = ".app-body__view";
export const BODY_SIGNED_OUT_VIEW_SELECTOR = ".app-body__view--signed-out";
export const BODY_SIGNED_IN_VIEW_SELECTOR = ".app-body__view--signed-in";
export const BODY_CONTENT_SIGNED_OUT_SELECTOR = ".app-body__view--signed-out .app-body__content";
export const BODY_CONTENT_SIGNED_IN_SELECTOR = ".app-body__view--signed-in .app-body__content";
export const BODY_MESSAGE_STACK_SELECTOR = ".app-body__message-stack";
export const BODY_MESSAGE_SPACER_SELECTOR = ".app-body__message--spacer";
export const BODY_MESSAGE_DISPLAY_SELECTOR = ".app-body__message--display";
export const BODY_ICON_SELECTOR = ".app-body__icon";

// Shared state classes.
export const BODY_HIDDEN_CLASS = "is-hidden";
export const BODY_CONTENT_HIDDEN_CLASS = "is-hidden";
export const BODY_ACTIVE_CLASS = "is-active";

// Animation phase classes.
export const BODY_ANIMATION_PENDING_CLASS = "is-body-animation-pending";
export const BODY_ICON_POP_PENDING_CLASS = "is-body-pop-pending";
export const BODY_ICON_POP_REVEALED_CLASS = "is-body-pop-revealed";
export const BODY_MESSAGE_TYPING_CLASS = "is-body-message-typing";

// Shared timing vars (defined on .app-body; read via animCssMsGet).
export const BODY_VAR_ICON_POP_MS = VAR_POP_MS;
export const BODY_VAR_MESSAGE_TYPE_MS = VAR_TYPE_MS;
export const BODY_VAR_ANIMATION_TIMEOUT_BUFFER_MS = VAR_BUFFER_MS;

// Copy.
export const BODY_SIGNED_OUT_MESSAGE_TEXT = "To use the authenticator\nsign in or sign up.";
export const BODY_SIGNED_IN_EMPTY_MESSAGE_TEXT = "Use + or scan a QR code\nto get started.";
