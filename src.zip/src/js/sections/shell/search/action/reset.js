import { searchActionFilter } from "./filter.js";

import { SEARCH_ANIMATION_PENDING_CLASS } from "../search-const.js";
import { SEARCH_FADE_IN_CLASS } from "../search-const.js";
import { SEARCH_HIDDEN_CLASS } from "../search-const.js";
import { SEARCH_INPUT_SELECTOR } from "../search-const.js";
import { SEARCH_ROOT_SELECTOR } from "../search-const.js";

/** Clears search input, hides the bar, and removes card filters. */
function searchActionReset() {
  const search = document.querySelector(SEARCH_ROOT_SELECTOR);
  const input = document.querySelector(SEARCH_INPUT_SELECTOR);

  if (input) {
    input.value = "";
  }

  search?.classList.remove(SEARCH_ANIMATION_PENDING_CLASS, SEARCH_FADE_IN_CLASS);
  search?.classList.add(SEARCH_HIDDEN_CLASS);
  searchActionFilter();
}

export { searchActionReset };
